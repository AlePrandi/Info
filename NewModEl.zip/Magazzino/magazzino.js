let url = "./magazzino.json";
let prod = document.getElementById("prod");
let cerca = document.getElementById("Cerca");
const datiProd = document.getElementById("datiProd");

let datiJSON;
let currentProductData;

fetch(url)
    .then(response => response.json())
    .then(data => {
        datiJSON = data;
    });

cerca.addEventListener("click", function (e) {
    clearForClass("datiProd");
    e.preventDefault();
    let trovato = false;

    datiJSON.forEach(riga => {
        if (riga.codiceProd === prod.value) {
            trovato = true;
            currentProductData = riga;
            datiProd.innerHTML = `
                <div class="container datiProd">
                    <div class="card cart">
                        <label class="title">${riga.marca} ${riga.modelloNome}</label>
                        <div class="steps">
                            <div class="step">
                                <div>
                                    <span>DETTAGLI PRODOTTO</span>
                                    <div class="details">
                                        <span>Marca: </span>
                                        <span class="editable" data-field="marca">${riga.marca}</span>
                                        <span>Modello: </span>
                                        <span class="editable" data-field="modelloNome">${riga.modelloNome}</span>
                                        <span>Reparto: </span>
                                        <span class="editable" data-field="reparto">${riga.reparto}</span>
                                        <span>Tipo: </span>
                                        <span class="editable" data-field="tipoProdotto">${riga.tipoProdotto}</span>
                                        <span>Codice prodotto: </span>
                                        <span class="editable" data-field="codiceProd">${riga.codiceProd}</span>
                                    </div>
                                </div>
                                <div>
                                    <span>DETTAGLI RESPONSABILE</span>
                                    <div class="details">
                                        <span>Nome:</span>
                                        <span class="editable" data-field="Nominativo_responsabile">${riga.Nominativo_responsabile}</span>
                                        <span>Telefono:</span>
                                        <span class="editable" data-field="cell_resp">${riga.cell_resp}</span>
                                    </div>
                                </div>
                                <div>
                                    <span>DETTAGLI MAGAZZINO</span>
                                    <div class="details">
                                        <span>${riga.fornitore1}: </span>
                                        <span class="editable" data-field="costo1">€${riga.costo1}</span>
                                        <span>${riga.fornitore2}: </span>
                                        <span class="editable" data-field="costo2">€${riga.costo2}</span>
                                        <span>Quantità: </span>
                                        <span class="editable" data-field="qt"> ${riga.qt} pz</span>
                                    </div>
                                </div>
                                <div class="payments">
                                    <span>AREA CLIENTI</span>
                                    <div class=" details">
                                        <span>Subtotale:</span>
                                        <span class="editable" data-field="prezzo">€${riga.prezzo}</span>
                                        <span>IVA:</span>
                                        <span class="editable" data-field="IVA">${riga.IVA}%</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card checkout">
                    <div class="footer">
                        <label class="price">€${parseFloat(riga.prezzo) + parseFloat(riga.prezzo) * parseFloat(riga.IVA) / 100}</label>
                        <button class="checkout-btn" id="modificaBtn">Modifica</button>
                    </div>
                </div>
                </div>
            `;

            let modificaBtn = document.getElementById("modificaBtn");

            modificaBtn.addEventListener("click", function () {
                if (modificaBtn.textContent === "Modifica") {
                    let editables = document.querySelectorAll(".editable");

                    editables.forEach(span => {
                        let fieldValue = span.textContent.trim();
                        let input = document.createElement("input");
                        input.value = fieldValue.replace("€", "").replace("%", "").replace(" pz", "");
                        input.dataset.field = span.dataset.field;
                        span.parentNode.replaceChild(input, span);
                    });

                    modificaBtn.textContent = "Salva modifiche";

                    let eliminaButton = document.createElement("button");
                    eliminaButton.textContent = "Elimina";
                    eliminaButton.classList.add("checkout-btn");
                    eliminaButton.style.marginLeft = "10px";
                    modificaBtn.parentNode.appendChild(eliminaButton);

                    eliminaButton.addEventListener("click", async function () {
                        let index = datiJSON.findIndex(riga => riga.codiceProd === currentProductData.codiceProd);

                        datiJSON.splice(index, 1);

                        datiProd.innerHTML = "";
                        if (datiJSON !== null) {
                            const jsonFile = new File([JSON.stringify(datiJSON)], "magazzino.json", {
                                type: "application/json",
                            });

                            const fileHandle = await window.showSaveFilePicker({
                                suggestedName: jsonFile.name,
                                types: [
                                    {
                                        description: "JSON file",
                                        accept: { "application/json": [".json"] },
                                    },
                                ],
                            });

                            const writableStream = await fileHandle.createWritable();
                            await writableStream.write(jsonFile);
                            await writableStream.close();

                            console.log("File saved successfully!");
                        } else {
                            alert("Dati non corretti o nulli.");
                        }
                    });
                } else {
                    let inputs = document.querySelectorAll("input[data-field]");
                    let updatedData = {};

                    inputs.forEach(input => {
                        let span = document.createElement("span");
                        span.classList.add("editable");
                        span.dataset.field = input.dataset.field;

                        if (input.dataset.field === "prezzo" || input.dataset.field === " costo1" || input.dataset.field === "costo2") {
                            span.textContent = "€" + input.value;
                        } else if (input.dataset.field === "IVA") {
                            span.textContent = input.value + "%";
                        } else if (input.dataset.field === "qt") {
                            span.textContent = input.value + " pz";
                        } else {
                            span.textContent = input.value;
                        }

                        input.parentNode.replaceChild(span, input);

                        if (input.dataset.field === "prezzo" || input.dataset.field === "IVA") {
                            updatedData[input.dataset.field] = parseFloat(input.value.replace("€", "").replace("%", ""));
                        } else {
                            updatedData[input.dataset.field] = input.value;
                        }
                    });

                    Object.keys(updatedData).forEach((key) => {
                        currentProductData[key] = updatedData[key];
                    });

                    let prezzo = parseFloat(currentProductData.prezzo);
                    let iva = parseFloat(currentProductData.IVA);
                    let prezzoConIvaSpan = document.querySelector(".price");

                    prezzoConIvaSpan.textContent = "€" + (prezzo + (prezzo * iva / 100)).toFixed(2);

                    modificaBtn.textContent = "Modifica";
                }
            });

            let salvaButton = document.createElement("button");
            salvaButton.id = "salvaButton";
            salvaButton.textContent = "Salva modifiche e scarica file";
            datiProd.appendChild(salvaButton);

            salvaButton.addEventListener("click", async () => {
                if (datiJSON !== null) {
                    const jsonFile = new File([JSON.stringify(datiJSON)], "magazzino.json", {
                        type: "application/json",
                    });

                    const fileHandle = await window.showSaveFilePicker({
                        suggestedName: jsonFile.name,
                        types: [
                            {
                                description: "JSON file",
                                accept: { "application/json": [".json"] },
                            },
                        ],
                    });

                    const writableStream = await fileHandle.createWritable();
                    await writableStream.write(jsonFile);
                    await writableStream.close();

                    console.log("File saved successfully!");
                } else {
                    alert("Dati non corretti o nulli.");
                }
            });
        }
    });

    if (!trovato) {
        datiProd.innerHTML = "Prodotto non trovato";
    }
});

function clearForClass(className) {
    let elements = document.getElementsByClassName(className);
    while (elements.length > 0) {
        elements[0].parentNode.removeChild(elements[0]);
    }
}

// Funzione per creare il pulsante "Nuovo Reparto"
function creaPulsanteNuovoReparto() {
    let nuovoRepartoBtn = document.createElement("button");
    nuovoRepartoBtn.textContent = "Nuovo Reparto";
    document.body.appendChild(nuovoRepartoBtn);

    nuovoRepartoBtn.addEventListener("click", function () {
        // Crea l'input per inserire il nuovo reparto
        let nuovoRepartoInput = document.createElement("input");
        nuovoRepartoInput.type = "text";
        nuovoRepartoInput.placeholder = "Inserisci il nuovo reparto";
        document.body.appendChild(nuovoRepartoInput);

        nuovoRepartoInput.addEventListener("keyup", function (e) {
            if (e.key === "Enter") {
                let newReparto = nuovoRepartoInput.value.trim();

                if (newReparto !== "") {
                    // Verifica se il nuovo reparto non è già presente
                    let existingReparti = datiJSON.map(riga => riga.reparto);
                    if (!existingReparti.includes(newReparto)) {
                        // Aggiunge il nuovo reparto alle opzioni del select
                        let repartoSelect = document.getElementById("reparto");
                        if (repartoSelect) {
                            let option = document.createElement("option");
                            option.textContent = newReparto;
                            repartoSelect.appendChild(option);
                        }

                        // Aggiunge il nuovo reparto all'array datiJSON
                        datiJSON.push({ reparto: newReparto });

                        nuovoRepartoInput.remove();
                    } else {
                        alert("Reparto già presente");
                    }
                } else {
                    alert("Inserisci il nome del reparto");
                }
            }
        });
    });
}

function creaPulsanteNuovo() {
    let nuovoBtn = document.createElement("button");
    nuovoBtn.textContent = "Nuovo";
    document.body.appendChild(nuovoBtn);

    nuovoBtn.addEventListener("click", function () {
        clearForClass("datiProd");
        datiProd.innerHTML = `
            <div class="container datiProd">
                <div class="card cart">
                    <label class="title">Nuovo Prodotto</label>
                    <div class="steps">
                        <div class="step">
                            <div>
                                <span>DETTAGLI PRODOTTO</span>
                                <div class="details">
                                    <span>Reparto: </span>
                                    <select id="reparto"></select>
                                    <span>Marca: </span>
                                    <input type="text" id="marca">
                                    <span>Modello: </span>
                                    <input type="text" id="modelloNome">
                                    <span>Tipo: </span>
                                    <input type="text" id="tipoProdotto">
                                    <span>Codice prodotto: </span>
                                    <input type="text" id="codiceProd">
                                </div>
                            </div>
                            <div>
                                <span>DETTAGLI RESPONSABILE</span>
                                <div class="details">
                                    <span>Nome:</span>
                                    <input type="text" id="Nominativo_responsabile">
                                    <span>Telefono:</span>
                                    <input type="text" id="cell_resp">
                                </div>
                            </div>
                            <div>
                                <span>DETTAGLI MAGAZZINO</span>
                                <div class="details">
                                    <span>Fornitore 1:</span>
                                    <input type="text" id="fornitore1">
                                    <span>Costo 1 :</span>
                                    <input type="text" id="costo1">
                                    <span>Fornitore 2:</span>
                                    <input type="text" id="fornitore2">
                                    <span>Costo 2:</span>
                                    <input type="text" id="costo2">
                                    <span>Quantità:</span>
                                    <input type="text" id="qt">
                                </div>
                            </div>
                            <div class="payments">
                                <span>AREA CLIENTI</span>
                                <div class="details">
                                    <span>Prezzo:</span>
                                    <input type="text" id="prezzo">
                                    <span>IVA:</span>
                                    <input type="text" id="IVA">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card checkout">
                        <div class="footer">
                            <label class="price">€0.00</label>
                            <button class="checkout-btn" id="salvaBtn">Salva</button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        let repartoSelect = document.getElementById("reparto");
        datiJSON.forEach(riga => {
            let option = document.createElement("option");
            option.textContent = riga.reparto;
            let options = Array.from(repartoSelect.options);
            if (!options.some(opt => opt.textContent === riga.reparto)) {
                repartoSelect.appendChild(option);
            }
        });

        let salvaButton = document.getElementById("salvaBtn");

        salvaButton.addEventListener("click", async function () {
            let nuovoProdotto = {
                reparto: document.getElementById("reparto").value,
                marca: document.getElementById("marca").value,
                modelloNome: document.getElementById("modelloNome").value,
                tipoProdotto: document.getElementById("tipoProdotto").value,
                codiceProd: document.getElementById("codiceProd").value,
                Nominativo_responsabile: document.getElementById("Nominativo_responsabile").value,
                cell_resp: parseInt(document.getElementById("cell_resp").value),
                fornitore1: document.getElementById("fornitore1").value,
                costo1: parseInt(document.getElementById("costo1").value),
                fornitore2: document.getElementById("fornitore2").value,
                costo2: parseInt(document.getElementById("costo2").value),
                qt: parseInt(document.getElementById("qt").value),
                prezzo: document.getElementById("prezzo").value,
                IVA: parseInt(document.getElementById("IVA").value),
            };

            datiJSON.push(nuovoProdotto);

            let datiProdInner = `
                <div class="container datiProd">
                    <div class="card cart">
                        <label class="title">${nuovoProdotto.marca} ${nuovoProdotto.modelloNome}</label>
                        <div class="steps">
                            <div class="step">
                                <div>
                                    <span>DETTAGLI PRODOTTO</span>
                                    <div class="details">
                                        <span>Marca: </span>
                                        <span class="editable" data-field="marca">${nuovoProdotto.marca}</span>
                                        <span>Modello: </span>
                                        <span class="editable" data-field="modelloNome">${nuovoProdotto.modelloNome}</span>
                                        <span>Tipo: </span>
                                        <span class="editable" data-field="tipoProdotto">${nuovoProdotto.tipoProdotto}</span>
                                        <span>Codice prodotto: </span>
                                        <span class="editable" data-field="codiceProd">${nuovoProdotto.codiceProd}</span>
                                    </div>
                                </div>
                                <div>
                                    <span>DETTAGLI RESPONSABILE</span>
                                    <div class="details">
                                        <span>Nome:</span>
                                        <span class="editable" data-field="Nominativo_responsabile">${nuovoProdotto.Nominativo_responsabile}</span>
                                        <span>Telefono:</span>
                                        <span class="editable" data-field="cell_resp">${nuovoProdotto.cell_resp}</span>
                                    </div>
                                </div>
                                <div>
                                    <span>DETTAGLI MAGAZZINO</span>
                                    <div class="details">
                                        <span>${nuovoProdotto.fornitore1}: </span>
                                        <span class="editable" data-field="costo1">€${nuovoProdotto.costo1}</span>
                                        <span>${nuovoProdotto.fornitore2}: </span>
                                        <span class="editable" data-field="costo2">€${nuovoProdotto.costo2}</span>
                                        <span>Quantità: </span>
                                        <span class="editable" data-field="qt"> ${nuovoProdotto.qt} pz</span>
                                    </div>
                                </div>
                                <div class="payments">
                                    <span>AREA CLIENTI</span>
                                    <div class="details">
                                        <span>Subtotale:</span>
                                        <span class="editable" data-field="prezzo">€${nuovoProdotto.prezzo}</span>
                                        <span>IVA:</span>
                                        <span class="editable" data-field="IVA">${nuovoProdotto.IVA}%</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card checkout">
                        <div class="footer">
                            <label class="price">€${parseFloat(nuovoProdotto.prezzo) + parseFloat(nuovoProdotto.prezzo) * parseFloat(nuovoProdotto.IVA) / 100}</label>
                            <button class="checkout-btn" id="modificaBtn">Modifica</button>
                        </div>
                    </div>
                </div>
            `;

            datiProd.innerHTML = datiProdInner;

            let modificaButton = document.getElementById("modificaBtn");

            modificaButton.addEventListener("click", function () {
                // codice per la modifica
            });

            // codice per salvare il file
            const jsonFile = new File([JSON.stringify(datiJSON)], "magazzino.json", {
                type: "application/json",
            });

            const fileHandle = await window.showSaveFilePicker({
                suggestedName: jsonFile.name,
                types: [
                    {
                        description: "JSON file",
                        accept: { "application/json": [".json"] },
                    },
                ],
            });

            const writableStream = await fileHandle.createWritable();
            await writableStream.write(jsonFile);
            await writableStream.close();

            console.log("File saved successfully!");
        });
    });
}

creaPulsanteNuovoReparto();
creaPulsanteNuovo();