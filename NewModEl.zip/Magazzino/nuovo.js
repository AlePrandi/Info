// Funzione per creare il pulsante "Nuovo Reparto"
function creaPulsanteNuovoReparto() {
    let nuovoRepartoBtn = document.createElement("button");
    nuovoRepartoBtn.textContent = "Nuovo Reparto";
    document.body.appendChild(nuovoRepartoBtn);

    nuovoRepartoBtn.addEventListener("click", function () {
        // Crea l'input per inserire il nuovo reparto
        let nuovoRepartoInput = document.createElement("input");
        nuovoRepartoInput.type = "text";
        nuovoRepartoInput.placeholder = "Inserisci il nuovo reparto";
        document.body.appendChild(nuovoRepartoInput);

        nuovoRepartoInput.addEventListener("keyup", function (e) {
            if (e.key === "Enter") {
                let newReparto = nuovoRepartoInput.value.trim();

                if (newReparto !== "") {
                    // Verifica se il nuovo reparto non è già presente
                    let existingReparti = datiJSON.map(riga => riga.reparto);
                    if (!existingReparti.includes(newReparto)) {
                        // Aggiunge il nuovo reparto alle opzioni del select
                        let repartoSelect = document.getElementById("reparto");
                        if (repartoSelect) {
                            let option = document.createElement("option");
                            option.textContent = newReparto;
                            repartoSelect.appendChild(option);
                        }

                        // Aggiunge il nuovo reparto all'array datiJSON
                        datiJSON.push({ reparto: newReparto });

                        nuovoRepartoInput.remove();
                    } else {
                        alert("Reparto già presente");
                    }
                } else {
                    alert("Inserisci il nome del reparto");
                }
            }
        });
    });
}

// Funzione per creare il pulsante "Nuovo"
function creaPulsanteNuovo() {
    let nuovoBtn = document.createElement("button");
    nuovoBtn.textContent = "Nuovo";
    document.body.appendChild(nuovoBtn);

    nuovoBtn.addEventListener("click", function () {
        clearForClass("datiProd");
        datiProd.innerHTML = `
            <div class="container datiProd">
                <div class="card cart">
                    <label class="title">Nuovo Prodotto</label>
                    <div class="steps">
                        <div class="step">
                            <div>
                                <span>DETTAGLI PRODOTTO</span>
                                <div class="details">
                                    <span>Reparto: </span>
                                    <select id="reparto"></select>
                                    <span>Marca: </span>
                                    <input type="text" id="marca">
                                    <span>Modello: </span>
                                    <input type="text" id="modelloNome">
                                    <span>Tipo: </span>
                                    <input type="text" id="tipoProdotto">
                                    <span>Codice prodotto: </span>
                                    <input type="text" id="codiceProd">
                                </div>
                            </div>
                            <div>
                                <span>DETTAGLI RESPONSABILE</span>
                                <div class="details">
                                    <span>Nome:</span>
                                    <input type="text" id="Nominativo_responsabile">
                                    <span>Telefono:</span>
                                    <input type="text" id="cell_resp">
                                </div>
                            </div>
                            <div>
                                <span>DETTAGLI MAGAZZINO</span>
                                <div class="details">
                                    <span>Fornitore 1:</span>
                                    <input type="text" id="fornitore1">
                                    <span>Costo 1 :</span>
                                    <input type="text" id="costo1">
                                    <span>Fornitore 2:</span>
                                    <input type="text" id="fornitore2">
                                    <span>Costo 2:</span>
                                    <input type="text" id="costo2">
                                    <span>Quantità:</span>
                                    <input type="text" id="qt">
                                </div>
                            </div>
                            <div class="payments">
                                <span>AREA CLIENTI</span>
                                <div class="details">
                                    <span>Prezzo:</span>
                                    <input type="text" id="prezzo">
                                    <span>IVA:</span>
                                    <input type="text" id="IVA">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card checkout">
                        <div class="footer">
                            <label class="price">€0.00</label>
                            <button class="checkout-btn" id="modificaBtn">Salva modifiche</button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        let repartoSelect = document.getElementById("reparto");
        datiJSON.forEach(riga => {
            let option = document.createElement("option");
            option.textContent = riga.reparto;
            let options = Array.from(repartoSelect.options);
            if (!options.some(opt => opt.textContent === riga.reparto)) {
                repartoSelect.appendChild(option);
            }
        });

        modificaBtn = document.getElementById("modificaBtn");

        modificaBtn.addEventListener("click", function () {
            let inputs = document.querySelectorAll("input");
            let updatedData = {};

            inputs.forEach(input => {
                updatedData[input.id] = input.value;
            });

            let reparto = document.getElementById("reparto").value;
            updatedData.reparto = reparto;

            // Create a new array with the updated product and all existing products
            let newData = [...datiJSON];
            newData.push(updatedData);

            const jsonFile = new File([JSON.stringify(newData)], "magazzino.json", {
                type: "application/json",
            });

            const fileHandle = window.showSaveFilePicker({
                suggestedName: jsonFile.name,
                types: [
                    {
                        description: "JSON file",
                        accept: { "application/json": [".json"] },
                    },
                ],
            });

            const writableStream = fileHandle.createWritable();
            writableStream.write(jsonFile);
            writableStream.close();

            console.log("File saved successfully!");
        });
    });
}

creaPulsanteNuovoReparto();
creaPulsanteNuovo();