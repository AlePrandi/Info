public class test {
    public static void main(String[] args) {
        Persona p1 = new Persona("mario", "rossi", "MRARSS920301");
        Studente stud = new Studente("andrea", "bianchi", "MARASD","A", "bocconi");
        Docente prof = new Docente("gianni", "grassi", "MAMMOFFA", "italiano", 1000f);

        System.out.println(p1.toString());
        System.out.println(stud.toString());
        System.out.println(prof.toString());
    }
}
